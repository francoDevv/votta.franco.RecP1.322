
package recuperatoriop1;


public class Doblistas extends Jugador implements RealizableSaque, PracticablePareja{
    public int MIN_VALOR = 1;
    public int MAX_VALOR = 10;
    private int indiceCoordinacion;

    public Doblistas(String nombre, int ranking, Superficie superficiePreferida, int indiceCoordinacion) {
        super(nombre, ranking, superficiePreferida);
        
        if (indiceCoordinacion < MIN_VALOR || indiceCoordinacion > MAX_VALOR) throw new IllegalArgumentException("Indice de coordinacion fuera de rango");
        
        this.indiceCoordinacion = indiceCoordinacion;
    }

    public int getIndiceCoordinacion() {
        return indiceCoordinacion;
    }

    public void setIndiceCoordinacion(int indiceCoordinacion) {
        this.indiceCoordinacion = indiceCoordinacion;
    }

    @Override
    public void saque() {
        System.out.println("Sacando desde doblista");
    }
    
    @Override
    public void practicar() {
        System.out.println("Practicando desde doblista");
    }

    @Override
    public String toString() {
        return "Doblistas{ " + super.toString() + " indiceCoordinacion = " + indiceCoordinacion + '}';
    }

    
}
