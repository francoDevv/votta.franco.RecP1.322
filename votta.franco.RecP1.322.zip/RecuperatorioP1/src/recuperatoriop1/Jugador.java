
package recuperatoriop1;


public class Jugador {
    private String nombre;
    private int ranking;
    private Superficie superficiePreferida;

    public Jugador(String nombre, int ranking, Superficie superficiePreferida) {
        if (nombre == null) throw new IllegalArgumentException("Nombre nulo");
        if (ranking < 1) throw new IllegalArgumentException("Ranking inexistente");
        
        
        this.nombre = nombre;
        this.ranking = ranking;
        this.superficiePreferida = superficiePreferida;
    }

    public String getNombre() {
        return nombre;
    }

    public int getRanking() {
        return ranking;
    }

    public Superficie getSuperficiePreferida() {
        return superficiePreferida;
    }
    
    @Override
    public boolean equals(Object o) {
    if (this == o) return true;
    if (!(o instanceof Jugador)) return false;

    Jugador jugador = (Jugador) o;

    return this.nombre.equalsIgnoreCase(jugador.nombre)
            && this.ranking == jugador.ranking;
    }
    
    protected String mostrar() {
        StringBuilder sb = new StringBuilder();
        sb.append("nombre = ").append(nombre);
        sb.append(" ranking = ").append(ranking);
        sb.append(" superficiePreferida = ").append(superficiePreferida);
        return sb.toString();
    
    }

    @Override
    public String toString() {
        return this.mostrar();
    }
}
