
package recuperatoriop1;


public class JugadorDuplicadoException extends RuntimeException{
    public JugadorDuplicadoException(String msg) {
        super(msg);
    }
}
