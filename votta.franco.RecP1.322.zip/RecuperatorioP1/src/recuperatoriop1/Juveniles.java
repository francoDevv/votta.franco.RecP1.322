
package recuperatoriop1;


public class Juveniles extends Jugador implements PracticablePareja{
    private boolean tutorDeportivo;

    public Juveniles(String nombre, int ranking, Superficie superficiePreferida, boolean tutorDeportivo) {
        super(nombre, ranking, superficiePreferida);
        this.tutorDeportivo = tutorDeportivo;
    }

    public boolean isTutorDeportivo() {
        return tutorDeportivo;
    }

    @Override
    public void practicar() {
        System.out.println("Practicando desde juvenil");
    }

    @Override
    public String toString() {
        return "Juveniles{ " + super.toString() + " tutorDeportivo = " + tutorDeportivo + '}';
    }
    
}
