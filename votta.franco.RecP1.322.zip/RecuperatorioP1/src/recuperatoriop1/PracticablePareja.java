
package recuperatoriop1;


public interface PracticablePareja {
    void practicar();
}
