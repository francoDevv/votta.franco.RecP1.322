
package recuperatoriop1;


public interface RealizableSaque {
    void saque();
}
