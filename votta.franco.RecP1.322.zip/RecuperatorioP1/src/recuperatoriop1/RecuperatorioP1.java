
package recuperatoriop1;


public class RecuperatorioP1 {

    
    public static void main(String[] args) {
        Torneo tor = new Torneo();
        
        //Ejemplo 1 : Agregar jugadores
        System.out.println("Agregar un jugador al torneo");
        Jugador j1 = new Singlistas("David Nalbandian", 3, Superficie.CEMENTO, 200);
        tor.agregarJugador(j1);
        
        try {
            Jugador jDuplicado = new Singlistas("David Nalbandian", 3, Superficie.CEMENTO, 200);
            tor.agregarJugador(jDuplicado);
        } catch (JugadorDuplicadoException ex) {
            System.out.println(ex.getMessage());
        }
        
        Jugador j2 = new Singlistas("Novak Djokovic", 1, Superficie.CESPED, 190);
        Jugador j3 = new Doblistas("Roger Federer", 2, Superficie.CESPED, 7);
        Jugador j4 = new Doblistas("Carlos Alcaraz", 4, Superficie.POLVO, 5);
        Jugador j5 = new Juveniles("Francisco Cerundolo", 40, Superficie.CEMENTO, true);
        Jugador j6 = new Juveniles("Joao Fonseca", 50, Superficie.POLVO, false);

        tor.agregarJugador(j2);
        tor.agregarJugador(j3);
        tor.agregarJugador(j4);
        tor.agregarJugador(j5);
        tor.agregarJugador(j6);
        
        //Ejemplo 2 : Mostrar jugadores registrados
        System.out.println("Jugadores registrados en el torneo");
        tor.mostrarJugador();
        
        //Ejemplo 3 : Saque y practica en pareja
        System.out.println("Saque y practica en pareja de los jugadores");
        tor.sacar();
        tor.practicaEnPareja();
        
        //Ejemplo 4 : Filtrar por superficie 
        System.out.println("Jugadores filtrados por su superficie preferida");
        tor.filtrarPorSuperficie(Superficie.POLVO);

        
        //Ejemplo 5 : Generar un resumen por tipo
        System.out.println("Generando un resumen por tipo de jugadores");
        tor.generarResumenPorTipo();
        
    }
}
