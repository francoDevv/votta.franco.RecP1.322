
package recuperatoriop1;


public class Singlistas extends Jugador implements RealizableSaque{
    private int velocidadSaque;

    public Singlistas(String nombre, int ranking, Superficie superficiePreferida, int velocidadSaque) {
        super(nombre, ranking, superficiePreferida);
        if (velocidadSaque < 1) throw new IllegalArgumentException("La velocidad de saque no puede ser 0");
        this.velocidadSaque = velocidadSaque;
    }

    public int getVelocidadSaque() {
        return velocidadSaque;
    }

    public void setVelocidadSaque(int velocidadSaque) {
        this.velocidadSaque = velocidadSaque;
    }

    @Override
    public void saque() {
        System.out.println("Sacando desde singlista");
    }

    @Override
    public String toString() {
        return "Singlistas{ " + super.toString() + " velocidadSaque= " + velocidadSaque + '}';
    }
    
    
    
    
}
