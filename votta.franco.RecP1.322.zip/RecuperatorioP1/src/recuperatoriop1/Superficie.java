
package recuperatoriop1;


public enum Superficie {
    POLVO,
    CESPED,
    CEMENTO
}
