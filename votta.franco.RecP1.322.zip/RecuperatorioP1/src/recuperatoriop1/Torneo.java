
package recuperatoriop1;

import java.util.ArrayList;


public class Torneo {
    private ArrayList<Jugador> jugadores = new ArrayList<>();
    
    public void agregarJugador(Jugador jugador) {
        if (jugador == null) throw new IllegalArgumentException("Jugador nulo");
        
        if (jugadores.contains(jugador)) throw new JugadorDuplicadoException("Jugador duplicado, ya existe " + jugador.getNombre() + " " + jugador.getRanking());
    
        jugadores.add(jugador);
    }
    
    public void mostrarJugador() {
        System.out.println("--- Listado de jugadores ---");
        if (jugadores.isEmpty()) {
            System.out.println("No hay jugadores para mostrar");
        } else {
            for (Jugador j : jugadores) {
                System.out.println("- " + j);
            }
        }
        
        System.out.println("-----------------------------");
    }
    
    public void sacar() {
        System.out.println("---- Saques de jugadores ----");
        if (jugadores.isEmpty()) {
            System.out.println("No hay jugadores para mostrar los saques");
            System.out.println("-----------------------------");
            return;
        } 
        
        for (Jugador j : jugadores) {
            if (j instanceof RealizableSaque) {
                ((RealizableSaque) j).saque();
            } else {
                System.out.println("El juvenil no puede sacar " + j.getNombre());
            }
        }
        
        System.out.println("-------------------------------");
    }
    
    public void practicaEnPareja() {
        System.out.println("---- Practica en pareja de los jugadores ----");
        if (jugadores.isEmpty()) {
            System.out.println("No hay jugadores para practicar en pareja");
            System.out.println("-----------------------------");
            return;
        } 
        
        for (Jugador j : jugadores) {
            if (j instanceof PracticablePareja) {
                ((PracticablePareja) j).practicar();
            } else {
                System.out.println("El singlista " + j.getNombre() + " no puede practicar en pareja");
            }
        }
        
        System.out.println("-------------------------------");
    }
    
    public void filtrarPorSuperficie(Superficie superficie) {
        System.out.println("---- Listado de la superficie preferida indicada ----");
        if (superficie == null) { 
            System.out.println("Superficie nula");
            System.out.println("---------------------");
            return;
        }
        
        if (jugadores.isEmpty()) {
            System.out.println("No hay jugadores para saber su superficie preferida");
            System.out.println("---------------------");
            return;
        }
        
        int encontrados = 0;
        ArrayList<Jugador> jugadoresSuperficiePreferida = new ArrayList<>();
        for (Jugador j : jugadores) {
            Superficie superficiePreferida = j.getSuperficiePreferida();
            if (superficiePreferida == superficie) {
                System.out.println("Jugador " + j.getNombre() + " agregado al listado de los jugadores con la superficie preferida " + j.getSuperficiePreferida());
                encontrados++;
                jugadoresSuperficiePreferida.add(j);
            }
        }
        
        if (encontrados == 0) {
            System.out.println("No se encontro ninguno, no hay jugadores que prefieran " + superficie);
        } else {
            System.out.println("Total de jugadores encontrados " + encontrados);
            System.out.println("Listado de jugadores " + jugadoresSuperficiePreferida);
        }
        
        System.out.println("---------------------");
    }
    
    public void generarResumenPorTipo() {
        System.out.println("---- Resumen por tipo de jugadores ----");
        
        if (jugadores.isEmpty()) {
            System.out.println("No hay jugadores");
            System.out.println("---------------------");
            return;
        }
        
        int jugadoresSinglistas = 0;
        int jugadoresDoblistas = 0;
        int jugadoresJuveniles = 0;
        
        for (Jugador j : jugadores) {
            if (j instanceof Singlistas) {
                jugadoresSinglistas++;
            } else if (j instanceof Doblistas) {
                jugadoresDoblistas++;
            } else {
                jugadoresJuveniles++;
            }
        }

        if (jugadoresSinglistas > 0) {
            System.out.println("Singlistas: " + jugadoresSinglistas);
        } else {
            System.out.println("No hay Singlistas registrados.");
        }
    
        if (jugadoresDoblistas > 0) {
            System.out.println("Doblistas: " + jugadoresDoblistas);
        } else {
            System.out.println("No hay Doblistas registrados.");
        }
        
        if (jugadoresJuveniles > 0) {
            System.out.println("Juveniles: " + jugadoresJuveniles);
        } else {
            System.out.println("No hay Juveniles registrados.");
        }
    } 
}
